window.addEventListener('scroll', function() {
    var scrollButton = document.getElementById('scrollButton');
    if (window.scrollY === 0) {
      scrollButton.style.display = 'none';
    } else {
      scrollButton.style.display = 'block';
      document.querySelector('.scroll-button').addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior:"smooth" });
      });
    }
  });
